#!/usr/bin/env bash

# LOCALE (accents UTF-8)

export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8


RED="\033[31m"
GREEN="\033[32m"
GRAY="\033[90m"
RESET="\033[0m"



typewriter() {
  local text="$1"
  local delay="${2:-0.02}"
  for (( i=0; i<${#text}; i++ )); do
    printf "%s" "${text:$i:1}"
    sleep "$delay"
  done
  printf "\n"
}


loading_bar() {
  local steps=24
  printf "["
  for ((i=0; i<steps; i++)); do
    printf "#"
    sleep 0.04
  done
  printf "] OK\n"
}


OS=$(uname -s)


detect_env() {
  if [[ "$OS" == "Darwin" ]]; then
    echo "macOS Host"
  elif grep -qi microsoft /proc/version; then
    echo "WSL"
  elif command -v systemd-detect-virt >/dev/null && systemd-detect-virt --quiet; then
    systemd-detect-virt
  else
    echo "Systeme Inconnu"
  fi
}


if [[ "$OS" == "Linux" ]]; then
  CPU=$(lscpu | grep "Model name" | sed 's/Model name:\s*//')
  RAM=$(free -h | awk '/Mem:/ {print $2}')
elif [[ "$OS" == "Darwin" ]]; then
  CPU=$(sysctl -n machdep.cpu.brand_string)
  RAM=$(sysctl -n hw.memsize | awk '{ printf "%.1fGi\n", $1/1024/1024/1024 }')
else
  CPU="Inconnu"
  RAM="Inconnue"
fi

KERNEL=$(uname -r)
HOST=$(hostname)
ENV=$(detect_env)


clear
typewriter "[BOOT] BUNKER-109 CONTROL INTERFACE"
sleep 0.3

printf "Verification de l'intgrité système "
loading_bar
sleep 0.2

typewriter "[OK] Processeur : $CPU" 0.01
typewriter "[OK] Memoire    : $RAM" 0.01
typewriter "[OK] Noyau      : $KERNEL" 0.01
typewriter "[OK] Hote       : $HOST" 0.01
typewriter "[OK] Env        : $ENV" 0.01

if [[ "$ENV" != "Bare Metal" && "$ENV" != "macOS Host" ]]; then
  typewriter "[WARN] Environnement virtualisé detecté..."
  sleep 0.3
  typewriter "[WARN] Observation accru..."
fi

sleep 0.6
typewriter "Chargement de l'interface restreinte..."
sleep 1
clear


sleep 0.1 && clear
sleep 0.1 && clear


typewriter "BUNKER-109 SYSTEM" 0.03
printf "%b----------------------------------------%b\n" "$GRAY" "$RESET"

typewriter "Projet      : Bunker109"
typewriter "Type        : Terminal / Escape Game"
typewriter "Environment : Linux  VM  WSL"
typewriter "Theme       : Psychologique / Underground / Horreur"
printf     "%bStatut      : %bOK%b\n\n" "$GRAY" "$GREEN" "$RESET"

typewriter "Auteur      : YouCriedForLess"
typewriter "Design      : YouCriedForLess"
typewriter "Lancement   : 2026"
printf "\n"

typewriter "Soyez silencieux..."
sleep 0.5
typewriter "Vous pourriez entendre ce que vous ne devriez pas..." 0.04

typewriter "WARNING YOU DON'T HAVE RIGHTS TO CREATE ANY SORT OF COPY OF THIS"
sleep 0.1
