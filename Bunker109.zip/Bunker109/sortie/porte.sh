#!/bin/bash

echo "=== SAS DE SORTIE — BUNKER 109 ==="
read -p "Code d'accès (chiffres uniquement) : " code

a="1"
b="0"
c="9"
d="0"
e="9"
f="0"
g="6"

real_code="$a$b$c$d$e$f$g"

if [ "$code" = "$real_code" ]; then
  echo "Accès autorisé."
  echo "La porte s’ouvre lentement."
  echo "Derrière vous, le bunker reste silencieux."
  echo "Vous ne savez toujours pas si quelque chose vous observait."
  echo "Mais vous savez que vous n’étiez pas censé survivre."
  echo "Chargement des crédits en cours..."

  sleep 6
  echo "Affichage des crédits dans 8 secondes..."
  sleep 1
  echo "Affichage des crédits dans 7 secondes..."
  sleep 1
  echo "Affichage des crédits dans 6 secondes..."
  sleep 1
  echo "Affichage des crédits dans 5 secondes..."
  sleep 1
  echo "Affichage des crédits dans 4 secondes..."
  sleep 1
  echo "Affichage des crédits dans 3 secondes..."
  sleep 1
  echo "Affichage des crédits dans 2 secondes..."
  sleep 1
  echo "Affichage des crédits dans 1 seconde..."
  sleep 1
  echo "Affichage des crédits en cours..."

  ./.credits.sh
else
  echo "Accès refusé."
fi
